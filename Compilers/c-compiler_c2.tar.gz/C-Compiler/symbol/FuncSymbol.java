package symbol;

import java.util.*;

public class FuncSymbol extends Symbol {

  private List<Integer> paramTypes;

  public FuncSymbol(int row, int col, String ID, int type, List<Integer> paramTypes) {
    super(row, col, ID, type);
    this.paramTypes = paramTypes;
  }

  public List<Integer> getParamTypes() {
    return paramTypes;
  }

  @Override
  public void printSymbol() {
    String sym;
    if (paramTypes != null) {
      sym = super.getID()+": ( ";
      for (Integer type: paramTypes) {
        sym+=typeToStr(type)+" ";
      }
      sym+=") -> "+ typeToStr(super.getType());
      }
    else {sym = super.getID()+": () -> "+ typeToStr(super.getType());}
    System.out.println(sym);
  }
}
