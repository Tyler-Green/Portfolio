package symbol;

public class ArraySymbol extends Symbol {

  private int size;

  public ArraySymbol(int row, int col, String ID, int type, int size) {
    super(row, col, ID, type);
    this.size = size;
  }

  @Override
  public void printSymbol() {
    String sym = super.getID()+": "+ typeToStr(super.getType());
    System.out.println(sym);
  }
}
