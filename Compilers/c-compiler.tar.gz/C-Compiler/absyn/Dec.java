package absyn;

abstract public class Dec extends Absyn {
  public final static int INT = 0;
  public final static int VOID = 1;
}
