package absyn;

public class FunctionDec extends Dec{

  public String ID;
  public TypeSpec type;
  public CompoundExp exps;
  public DecList params;

  public FunctionDec(int row, int col, String ID, TypeSpec type, DecList params, CompoundExp exps){
    this.row = row;
    this.col = col;
    this.ID = ID;
    this.type = type;
    this.params = params;
    this.exps = exps;
  }

  public void accept( AbsynVisitor visitor, int level ) {
    visitor.visit( this, level );
  }
}
