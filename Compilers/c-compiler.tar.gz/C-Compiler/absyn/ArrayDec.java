package absyn;

public class ArrayDec extends Dec{


  public String ID;
  public TypeSpec type;
  public  int size;

  public ArrayDec(int row, int col, String ID, int size, TypeSpec type){
    this.row = row;
    this.col = col;
    this.ID = ID;
    this.type = type;
    this.size = size;
  }

  public void accept( AbsynVisitor visitor, int level ) {
    visitor.visit( this, level );
  }
}
