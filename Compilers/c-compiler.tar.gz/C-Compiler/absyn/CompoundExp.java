package absyn;

public class CompoundExp extends Exp{
  public DecList vars;
  public ExpList exps;

  public CompoundExp(int row, int col, DecList vars, ExpList exps) {
    this.row = row;
    this.col = col;
    this. vars = vars;
    this.exps = exps;
  }

  public void accept( AbsynVisitor visitor, int level ) {
    visitor.visit( this, level );
  }
}
