package absyn;

public class SimpleDec extends Dec{

  public String ID;
  public TypeSpec type;

  public SimpleDec(int row, int col, String ID, TypeSpec type){
    this.row = row;
    this.col = col;
    this.ID = ID;
    this.type = type;
  }

  public void accept( AbsynVisitor visitor, int level ) {
    visitor.visit( this, level );
  }
}
